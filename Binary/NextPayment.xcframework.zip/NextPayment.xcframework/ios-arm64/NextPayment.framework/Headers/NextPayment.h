//
//  NextPayment.h
//  NextPayment
//
//  Created by László Szöllősi on 2023. 06. 23..
//

#import <Foundation/Foundation.h>

//! Project version number for NextPayment.
FOUNDATION_EXPORT double NextPaymentVersionNumber;

//! Project version string for NextPayment.
FOUNDATION_EXPORT const unsigned char NextPaymentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NextPayment/PublicHeader.h>


